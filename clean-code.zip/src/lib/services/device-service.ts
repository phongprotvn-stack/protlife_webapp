import { supabase } from '@/lib/supabase/client';

export interface UserDevice {
  id: string;
  user_id: string;
  device_name: string;
  login_method: string;
  session_id: string | null;
  last_active: string;
  created_at: string;
}

const DEVICE_ID_KEY = 'protlife-device-id';

/**
 * Record a successful login by inserting into user_devices table.
 * Stores the new device record's ID in localStorage for "current device" detection.
 */
export async function recordDeviceLogin(userId: string, method: string, sessionId?: string | null): Promise<void> {
  try {
    const deviceName = navigator.userAgent;
    // If caller didn't provide sessionId, try to extract from current session
    if (sessionId === undefined) {
      try {
        const { data: { session } } = await supabase.auth.getSession();
        const token = session?.access_token;
        if (token) {
          const payload = JSON.parse(atob(token.split('.')[1]));
          sessionId = payload?.session_id || null;
        }
      } catch { /* non-critical */ }
    }
    const { data, error } = await supabase
      .from('user_devices')
      .insert({
        user_id: userId,
        device_name: deviceName,
        login_method: method,
        session_id: sessionId,
        last_active: new Date().toISOString(),
      })
      .select('id')
      .single();

    if (error) throw error;
    if (data?.id) {
      localStorage.setItem(DEVICE_ID_KEY, data.id);
    }
  } catch (e: any) {
    // Silently fail — device logging should never block login
    console.warn('[device-service] Failed to record device login:', e?.message);
  }
}

/**
 * Fetch all devices for the current user, newest first.
 */
export async function getUserDevices(): Promise<UserDevice[]> {
  const { data, error } = await supabase
    .from('user_devices')
    .select('*')
    .order('last_active', { ascending: false });

  if (error) throw error;
  return data || [];
}

/**
 * Delete a device record.
 */
export async function deleteDevice(deviceId: string): Promise<void> {
  const { error } = await supabase
    .from('user_devices')
    .delete()
    .eq('id', deviceId);

  if (error) throw error;
}

/**
 * Delete all devices except the specified one (current device).
 */
export async function deleteOtherDevices(currentDeviceId: string): Promise<void> {
  const { error } = await supabase
    .from('user_devices')
    .delete()
    .neq('id', currentDeviceId);

  if (error) throw error;
}

/**
 * Get the stored current device ID from localStorage.
 */
export function getCurrentDeviceId(): string | null {
  if (typeof window === 'undefined') return null;
  return localStorage.getItem(DEVICE_ID_KEY);
}

/**
 * Format user agent string into a short readable name.
 */
export function formatDeviceName(ua: string): string {
  let os = '';
  let browser = '';

  // OS detection: check mobile/tablet strings BEFORE desktop ones
  // (iPhone User-Agent also contains "like Mac OS X")
  if (ua.includes('iPhone') || ua.includes('iPad')) os = 'iOS';
  else if (ua.includes('Android')) os = 'Android';
  else if (ua.includes('Windows')) os = 'Windows';
  else if (ua.includes('Mac OS X') || ua.includes('Macintosh')) os = 'macOS';
  else if (ua.includes('Linux')) os = 'Linux';
  else os = 'Unknown';

  // Browser detection: check "pretend-Chrome" browsers BEFORE Chrome itself
  // (Edg/Edge/OPR/Opera all contain "Chrome" in their User-Agent)
  if (ua.includes('Edg/') || ua.includes('Edge/')) browser = 'Edge';
  else if (ua.includes('OPR/') || ua.includes('Opera/')) browser = 'Opera';
  else if (ua.includes('Firefox/')) browser = 'Firefox';
  else if (ua.includes('Chrome/')) browser = 'Chrome';
  // Safari check — only if NOT Chrome (iOS Safari doesn't include "Chrome")
  else if (ua.includes('Safari/')) browser = 'Safari';
  else browser = 'Unknown';

  // Determine device type
  let deviceType = os;
  if (ua.includes('iPhone')) deviceType = 'iPhone';
  else if (ua.includes('iPad')) deviceType = 'iPad';
  else if (ua.includes('Android') && ua.includes('Mobile') === false) deviceType = 'Android Tablet';
  else if (ua.includes('Android')) deviceType = 'Android Phone';
  else if (ua.includes('Windows') && ua.includes('ARM')) deviceType = 'Windows (ARM)';

  const shortUa = `${deviceType} · ${browser}`;
  // Max 50 chars to avoid super long names
  return shortUa.length > 50 ? shortUa.slice(0, 47) + '...' : shortUa;
}

/**
 * Get a simple icon for a device based on user agent.
 */
export function getDeviceIcon(ua: string): string {
  if (ua.includes('iPhone') || ua.includes('iPad')) return '📱';
  if (ua.includes('Android') && ua.includes('Mobile')) return '📱';
  if (ua.includes('Android')) return '📟';
  if (ua.includes('Macintosh') || ua.includes('Mac OS')) return '💻';
  if (ua.includes('Windows')) return '🖥️';
  if (ua.includes('Linux')) return '🐧';
  return '📱';
}
